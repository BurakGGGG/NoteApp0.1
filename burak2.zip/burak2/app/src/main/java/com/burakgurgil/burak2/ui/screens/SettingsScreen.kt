package com.burakgurgil.burak2.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.burakgurgil.burak2.ui.theme.ThemeType
import com.burakgurgil.burak2.ui.theme.themeColors
import com.burakgurgil.burak2.ui.theme.ThemeColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentTheme: ThemeType,
    onThemeChange: (ThemeType) -> Unit,
    onDismiss: () -> Unit
) {
    val currentColors = themeColors[currentTheme] ?: themeColors[ThemeType.DEFAULT]!!

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Ayarlar",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        color = currentColors.textPrimary
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .padding(start = 8.dp)
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                    ) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "Geri",
                            tint = currentColors.textPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = currentColors.textPrimary
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text(
                "Tema Seçimi",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold
                ),
                color = currentColors.textPrimary
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            ThemeOption(
                title = "Varsayılan",
                description = "Modern ve ferah bir görünüm",
                emoji = "⚪",
                isSelected = currentTheme == ThemeType.DEFAULT,
                onClick = { onThemeChange(ThemeType.DEFAULT) },
                colors = currentColors
            )
            
            ThemeOption(
                title = "Koyu",
                description = "Göz yorgunluğunu azaltan koyu mod",
                emoji = "🌙",
                isSelected = currentTheme == ThemeType.DARK,
                onClick = { onThemeChange(ThemeType.DARK) },
                colors = currentColors
            )
            
            ThemeOption(
                title = "İlkbahar",
                description = "Taze ve canlı yeşil tonları",
                emoji = "🌱",
                isSelected = currentTheme == ThemeType.SPRING,
                onClick = { onThemeChange(ThemeType.SPRING) },
                colors = currentColors
            )
            
            ThemeOption(
                title = "Yaz",
                description = "Parlak ve enerjik sarı tonları",
                emoji = "☀️",
                isSelected = currentTheme == ThemeType.SUMMER,
                onClick = { onThemeChange(ThemeType.SUMMER) },
                colors = currentColors
            )
            
            ThemeOption(
                title = "Sonbahar",
                description = "Sıcak ve huzur veren turuncu tonları",
                emoji = "🍁",
                isSelected = currentTheme == ThemeType.AUTUMN,
                onClick = { onThemeChange(ThemeType.AUTUMN) },
                colors = currentColors
            )
            
            ThemeOption(
                title = "Kış",
                description = "Sakin ve ferah mavi tonları",
                emoji = "❄️",
                isSelected = currentTheme == ThemeType.WINTER,
                onClick = { onThemeChange(ThemeType.WINTER) },
                colors = currentColors
            )
        }
    }
}

@Composable
fun ThemeOption(
    title: String,
    description: String,
    emoji: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    colors: ThemeColors
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) 
                colors.primary.copy(alpha = 0.15f)
            else 
                MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = emoji,
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (isSelected) 
                        colors.textPrimary
                    else 
                        colors.textSecondary
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isSelected) 
                        colors.textPrimary.copy(alpha = 0.8f)
                    else 
                        colors.textSecondary.copy(alpha = 0.7f)
                )
            }
            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Seçili",
                    tint = colors.textPrimary
                )
            }
        }
    }
} 